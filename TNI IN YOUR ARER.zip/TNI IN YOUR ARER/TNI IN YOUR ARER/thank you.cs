﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TNI_IN_YOUR_ARER
{
	public partial class Form2 : Form
	{
		public Form2()
		{
			InitializeComponent();
		}

		private void Button1_Click(object sender, EventArgs e)
		{
			this.Hide();
			Login L1 = new Login();
			L1.ShowDialog();
		}

		private void Button2_Click(object sender, EventArgs e)
		{
			this.Hide();
			Zone Z1 = new Zone();
			Z1.ShowDialog();
		}
	}
}
