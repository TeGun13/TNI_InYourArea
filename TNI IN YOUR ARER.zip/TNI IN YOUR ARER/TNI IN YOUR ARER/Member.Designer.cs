﻿namespace TNI_IN_YOUR_ARER
{
	partial class Member
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button4 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.trueh = new System.Windows.Forms.Button();
			this.dtac = new System.Windows.Forms.Button();
			this.ais = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// button4
			// 
			this.button4.BackColor = System.Drawing.Color.Salmon;
			this.button4.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.button4.Location = new System.Drawing.Point(362, 361);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(242, 49);
			this.button4.TabIndex = 32;
			this.button4.Text = "Don\'t have Click";
			this.button4.UseVisualStyleBackColor = false;
			this.button4.Click += new System.EventHandler(this.Button4_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(290, 33);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(375, 65);
			this.label1.TabIndex = 28;
			this.label1.Text = "Which Member?";
			// 
			// trueh
			// 
			this.trueh.BackgroundImage = global::TNI_IN_YOUR_ARER.Properties.Resources.ดาวน์โหลด;
			this.trueh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.trueh.Location = new System.Drawing.Point(662, 136);
			this.trueh.Name = "trueh";
			this.trueh.Size = new System.Drawing.Size(180, 178);
			this.trueh.TabIndex = 31;
			this.trueh.UseVisualStyleBackColor = true;
			this.trueh.Click += new System.EventHandler(this.Button3_Click);
			// 
			// dtac
			// 
			this.dtac.BackgroundImage = global::TNI_IN_YOUR_ARER.Properties.Resources.dtac;
			this.dtac.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.dtac.Location = new System.Drawing.Point(390, 136);
			this.dtac.Name = "dtac";
			this.dtac.Size = new System.Drawing.Size(180, 178);
			this.dtac.TabIndex = 30;
			this.dtac.UseVisualStyleBackColor = true;
			this.dtac.Click += new System.EventHandler(this.Button2_Click);
			// 
			// ais
			// 
			this.ais.BackgroundImage = global::TNI_IN_YOUR_ARER.Properties.Resources.AIS;
			this.ais.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.ais.Location = new System.Drawing.Point(114, 136);
			this.ais.Name = "ais";
			this.ais.Size = new System.Drawing.Size(180, 178);
			this.ais.TabIndex = 29;
			this.ais.UseVisualStyleBackColor = true;
			this.ais.Click += new System.EventHandler(this.Ais_Click);
			// 
			// Member
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImage = global::TNI_IN_YOUR_ARER.Properties.Resources.Project_BG;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.ClientSize = new System.Drawing.Size(952, 501);
			this.Controls.Add(this.button4);
			this.Controls.Add(this.trueh);
			this.Controls.Add(this.dtac);
			this.Controls.Add(this.ais);
			this.Controls.Add(this.label1);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Member";
			this.Text = "Member";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button trueh;
		private System.Windows.Forms.Button dtac;
		private System.Windows.Forms.Button ais;
		private System.Windows.Forms.Label label1;
	}
}