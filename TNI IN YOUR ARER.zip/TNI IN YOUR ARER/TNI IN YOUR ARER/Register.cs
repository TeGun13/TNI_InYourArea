﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace TNI_IN_YOUR_ARER
{
	public partial class Register : Form
	{
		public Register()
		{
			InitializeComponent();
		}

		private void Confirm_Click(object sender, EventArgs e)
		{
			bool check = true;
			if (Checkname(firstname.Text, surname.Text))
			{
				check = false;
				MessageBox.Show("Please input your First name or Sur name, again", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}
			if (!Checkmail(mail.Text))
			{
				check = false;
				MessageBox.Show("Input E-mail worng. \n" + "Please try again.\n", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}
			if (Checkuser(User.Text))
			{
				check = false;
				MessageBox.Show("This username is already in use.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}
			if (!Checkpass(password.Text, repassword.Text))
			{
				check = false;
				MessageBox.Show("1.Your password must contain at least 5 character.\n" + "2. Your password and re-password isn't match.\n", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}
			if (check == true)
			{
				Program.id = User.Text;
				StreamWriter sw = new StreamWriter(Program.filename, true);
				sw.WriteLine("{0}*{1}*{2}*{3}*{4}*{5}", firstname.Text, surname.Text, mail.Text, User.Text, password.Text, repassword.Text);
				sw.Close();

				MessageBox.Show("Sign Up Complete ! \n"+"You can login");
				this.Hide();

				Login f2 = new Login();
				f2.ShowDialog();
			}

		}

		private void Button1_Click(object sender, EventArgs e)
		{
			this.Hide();
			Login f2 = new Login();
			f2.ShowDialog();
		}

		private void TextBox1_TextChanged(object sender, EventArgs e)
		{

		}

		private void TextBox6_TextChanged(object sender, EventArgs e)
		{

		}
		static bool Checkname(string fname, string sname)
		{
			bool check = false;
			if (fname.Equals("") || sname.Equals(""))
			{
				check = true;
			}
			/*try
			{
				if (id.Equals("Username") || mail.Equals("E-mail(@tni.ac.th)") || repass.Equals("Re-Password") || pass.Equals("Password"))
				{
					check = true;
				}
				else if (!mail.EndsWith("@tni.ac.th"))
					check = true;
				string[] data = { fname, sname, id, mail, pass, repass };
				foreach (string _data in data)
				{
					if (_data.IndexOf(' ') >= 0)
						check = true;
					else if (_data.IndexOf('*') >= 0)
						check = true;
					else if (_data.Equals(""))
						check = true;
				}
			}
			catch
			{
				check = true;
			}*/
			return check;
		}
		static bool Checkmail(string mail)
		{
			bool check = false;
			if (mail.EndsWith("@tni.ac.th") || mail.EndsWith("@hotmail.com") ||mail.EndsWith("@outlook.com") ||mail.EndsWith("@gmail.com"))
			{
				check = true;
			}
			if (check == true)
			{
				try
				{
					StreamReader sr = new StreamReader(Program.filename);
					string temp = "";
					while ((temp = sr.ReadLine()) != null)
					{
						string[] mailInfile = temp.Split('*');
						if (mail.Equals(mailInfile[2]))
						{
							check = true;
						}
					}
					sr.Close();
				}
				catch (IOException)
				{
					StreamWriter sw = new StreamWriter(Program.filename,true);
					sw.Close();

				}
			}
			return check;
		}
		
		static bool Checkuser(string user)
		{
			bool check = false;
			try
			{
				StreamReader sr = new StreamReader(Program.filename);
				string temp = "";
				while ((temp = sr.ReadLine())!= null)
				{
					string[] UsernameInfile = temp.Split('*');
					if (user.Equals(UsernameInfile[3]))
					{
						check = true;
					}
				}
				sr.Close();
			}
			catch (IOException)
			{
				StreamWriter sw = new StreamWriter(Program.filename,true);
				sw.Close();

			}
			return check;
		}
		static bool Checkpass(string pass , string re_pass)
		{
			return (pass.Equals(re_pass)) && pass.Length >= 5;
		}
		
	}
}
