﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace TNI_IN_YOUR_ARER
{
	public partial class Total : Form
	{
		public Total()
		{
			InitializeComponent();
		}

		private void Button2_Click(object sender, EventArgs e)
		{
			this.Hide();
			Form2 ty = new Form2();
			ty.ShowDialog();
		}

		private void Button1_Click(object sender, EventArgs e)
		{

		}

		private void ListView1_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		private void ListView3_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		private void Label10_Click(object sender, EventArgs e)
		{


		}

		private void Label10_Click_1(object sender, EventArgs e)
		{

		}

		private void Unit_zone_Paint(object sender, PaintEventArgs e)
		{
			unit_zone.Text = Program.seat.ToString();
		}

		private void Price_zone_Paint(object sender, PaintEventArgs e)
		{
			price_zone.Text = Program.total.ToString();
		}

		private void Price_zone_Click(object sender, EventArgs e)
		{

		}

		private void Label6_Paint(object sender, PaintEventArgs e)
		{
			ZONE.Text = Program.Zone;
		}

		private void Label17_Click(object sender, EventArgs e)
		{

		}

		private void Label17_Paint(object sender, PaintEventArgs e)
		{
			unitTNI.Text = Program.Allproduct.ToString();
		}

		private void Label16_Paint(object sender, PaintEventArgs e)
		{
			priceTNI.Text = Program.ALLunitproduct.ToString();
		}

		private void Label6_Click(object sender, EventArgs e)
		{

		}

		private void Label13_Click(object sender, EventArgs e)
		{

		}

		private void Label13_Paint(object sender, PaintEventArgs e)
		{
			StreamReader sr = new StreamReader("D:\\TOTAL.txt");
			string temp = "";
			while ((temp = sr.ReadLine())!=null)
			{
				string[] data = temp.Split('*');
				//[3] = Member
				if (data[3].Equals("DTAC") && data[0].Equals(Program.id))
				{
					label13.Text = "DTAC -----> Discount 5 %";
				}
				else if (data[3].Equals("TRUE") && data[0].Equals(Program.id))
				{
					label13.Text = "TRUE -----> Discount 10 %";
				}
				else if (data[3].Equals("AIS") && data[0].Equals(Program.id))
				{
					label13.Text = "AIS -----> Discount 15 %";
				}
				else if (data[3].Equals("NONE") && data[0].Equals(Program.id))
				{
					label13.Text = "-";
				}
			}
			
		}

		private void Label12_Paint(object sender, PaintEventArgs e)
		{
			
		}

		private void Label6_Paint_1(object sender, PaintEventArgs e)
		{
			StreamReader sr = new StreamReader("D:\\TOTAL.txt");
			string temp = "";
			while ((temp = sr.ReadLine()) != null)
			{
				string[] data = temp.Split('*');
				//[3] = Member
				//[4] = Total
				if (data[3].Equals("DTAC") && data[0].Equals(Program.id))
				{
					T.Text = data[4];
				}
				else if (data[3].Equals("TRUE") && data[0].Equals(Program.id))
				{
					T.Text = data[4];
				}
				else if (data[3].Equals("AIS") && data[0].Equals(Program.id))
				{
					T.Text = data[4];
				}
				else if (data[3].Equals("NONE") && data[0].Equals(Program.id))
				{
					T.Text = data[4];
				}

			}
		}
	}
}
