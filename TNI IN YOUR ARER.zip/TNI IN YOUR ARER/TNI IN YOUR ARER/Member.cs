﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace TNI_IN_YOUR_ARER
{
	public partial class Member : Form
	{
		public Member()
		{
			InitializeComponent();
		}

		private void Button3_Click(object sender, EventArgs e)
		{
			Program.ALLunitproduct = Program.YPRODUCT + Program.WPRODUCT;
			double price = Program.total + Program.ALLunitproduct;
			double discount = (price * 10) / 100;
			double sum = price - (discount);
			Program.Allproduct = Program.Yproduct + Program.Wproduct;
			Program.discount = sum ;


			StreamWriter sw = new StreamWriter("D:\\TOTAL.txt", true);
			sw.WriteLine("{0}*{1}*Product={2}*TRUE*{3:n}", Program.id, Program.Zone, Program.Yproduct + Program.Wproduct, sum );
			sw.Close();
			Program.discount = sum;
			MessageBox.Show("You are TRUE member?", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			this.Hide(); 
			Total ta = new Total();
			ta.ShowDialog();
			
			
		}

		private void Button2_Click(object sender, EventArgs e)
		{
			Program.ALLunitproduct = Program.YPRODUCT + Program.WPRODUCT;
			double price = Program.total + Program.ALLunitproduct;
			double discount = (price * 5) / 100;
			double sum = price - (discount);
			Program.Allproduct = Program.Yproduct + Program.Wproduct;
			Program.discount = sum;

			StreamWriter sw = new StreamWriter("D:\\TOTAL.txt", true);
			sw.WriteLine("{0}*{1}*Product={2}*DTAC*{3:n}", Program.id, Program.Zone, Program.Yproduct + Program.Wproduct, sum );
			sw.Close();
			Program.discount = sum;
			MessageBox.Show("You are Dtac member?", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			this.Hide();
			Total ta = new Total();
			ta.ShowDialog();
		
		}

		private void Button6_Click(object sender, EventArgs e)
		{
			this.Hide();
			Zone z1 = new Zone();
			z1.ShowDialog();
		}
		private void Ais_Click(object sender, EventArgs e)
		{

			Program.ALLunitproduct = Program.YPRODUCT + Program.WPRODUCT;
			double price = Program.total + Program.ALLunitproduct;
			double discount = (price * 15) / 100;
			double sum = price - (discount);
			Program.Allproduct = Program.Yproduct + Program.Wproduct;
			Program.discount = sum;

			StreamWriter sw = new StreamWriter("D:\\TOTAL.txt", true);
			sw.WriteLine("{0}*{1}*Product={2}*AIS*{3:n}", Program.id, Program.Zone, Program.Yproduct + Program.Wproduct, sum);
			sw.Close();
			Program.discount = sum;
			MessageBox.Show("You are AIS member?","Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			this.Hide();
			Total ta = new Total();
			ta.ShowDialog();
			
		}

		private void Button4_Click(object sender, EventArgs e)
		{
			Program.ALLunitproduct = Program.YPRODUCT + Program.WPRODUCT;
			double price = Program.total + Program.ALLunitproduct;
			double discount = 0;
			double sum = price - (discount);
			Program.Allproduct = Program.Yproduct + Program.Wproduct;
			Program.discount = sum;

			StreamWriter sw = new StreamWriter("D:\\TOTAL.txt", true);
			sw.WriteLine("{0}*{1}*Product={2}*NONE*{3}", Program.id, Program.Zone, Program.Yproduct + Program.Wproduct, sum);
			sw.Close();
			Program.discount = sum;
			this.Hide();
			Total ta = new Total();
			ta.ShowDialog();
		}
	}
}
