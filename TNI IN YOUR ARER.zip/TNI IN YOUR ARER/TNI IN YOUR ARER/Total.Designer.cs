﻿namespace TNI_IN_YOUR_ARER
{
	partial class Total
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.button2 = new System.Windows.Forms.Button();
			this.label5 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.pictureBox8 = new System.Windows.Forms.PictureBox();
			this.pictureBox7 = new System.Windows.Forms.PictureBox();
			this.pictureBox4 = new System.Windows.Forms.PictureBox();
			this.pictureBox3 = new System.Windows.Forms.PictureBox();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.pictureBox5 = new System.Windows.Forms.PictureBox();
			this.pictureBox9 = new System.Windows.Forms.PictureBox();
			this.ZONE = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.unit_zone = new System.Windows.Forms.Label();
			this.price_zone = new System.Windows.Forms.Label();
			this.priceTNI = new System.Windows.Forms.Label();
			this.unitTNI = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.T = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
			this.SuspendLayout();
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.BackColor = System.Drawing.Color.MistyRose;
			this.label4.Font = new System.Drawing.Font("Yu Gothic UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.ForeColor = System.Drawing.Color.Black;
			this.label4.Location = new System.Drawing.Point(669, 154);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(67, 37);
			this.label4.TabIndex = 36;
			this.label4.Text = "Unit";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.BackColor = System.Drawing.Color.MistyRose;
			this.label3.Font = new System.Drawing.Font("Yu Gothic UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.Black;
			this.label3.Location = new System.Drawing.Point(324, 154);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(137, 37);
			this.label3.TabIndex = 34;
			this.label3.Text = "PRODUCT";
			// 
			// button2
			// 
			this.button2.BackColor = System.Drawing.Color.Salmon;
			this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
			this.button2.ForeColor = System.Drawing.Color.White;
			this.button2.Location = new System.Drawing.Point(676, 394);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(127, 38);
			this.button2.TabIndex = 50;
			this.button2.Text = "Confirm";
			this.button2.UseVisualStyleBackColor = false;
			this.button2.Click += new System.EventHandler(this.Button2_Click);
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.BackColor = System.Drawing.Color.MistyRose;
			this.label5.Font = new System.Drawing.Font("Yu Gothic UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.ForeColor = System.Drawing.Color.Black;
			this.label5.Location = new System.Drawing.Point(603, 339);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(74, 37);
			this.label5.TabIndex = 47;
			this.label5.Text = "Total";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.BackColor = System.Drawing.Color.MistyRose;
			this.label2.Font = new System.Drawing.Font("Yu Gothic UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.Black;
			this.label2.Location = new System.Drawing.Point(772, 154);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(86, 37);
			this.label2.TabIndex = 33;
			this.label2.Text = "PRICE";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.Transparent;
			this.label1.Location = new System.Drawing.Point(54, 52);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(393, 86);
			this.label1.TabIndex = 28;
			this.label1.Text = "TOTAL COST";
			// 
			// pictureBox8
			// 
			this.pictureBox8.BackColor = System.Drawing.Color.Salmon;
			this.pictureBox8.Location = new System.Drawing.Point(573, 438);
			this.pictureBox8.Name = "pictureBox8";
			this.pictureBox8.Size = new System.Drawing.Size(324, 10);
			this.pictureBox8.TabIndex = 46;
			this.pictureBox8.TabStop = false;
			// 
			// pictureBox7
			// 
			this.pictureBox7.BackColor = System.Drawing.Color.Salmon;
			this.pictureBox7.Location = new System.Drawing.Point(573, 371);
			this.pictureBox7.Name = "pictureBox7";
			this.pictureBox7.Size = new System.Drawing.Size(10, 77);
			this.pictureBox7.TabIndex = 45;
			this.pictureBox7.TabStop = false;
			// 
			// pictureBox4
			// 
			this.pictureBox4.BackColor = System.Drawing.Color.Salmon;
			this.pictureBox4.Location = new System.Drawing.Point(888, 145);
			this.pictureBox4.Name = "pictureBox4";
			this.pictureBox4.Size = new System.Drawing.Size(10, 303);
			this.pictureBox4.TabIndex = 32;
			this.pictureBox4.TabStop = false;
			// 
			// pictureBox3
			// 
			this.pictureBox3.BackColor = System.Drawing.Color.Salmon;
			this.pictureBox3.Location = new System.Drawing.Point(132, 141);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new System.Drawing.Size(10, 236);
			this.pictureBox3.TabIndex = 31;
			this.pictureBox3.TabStop = false;
			// 
			// pictureBox2
			// 
			this.pictureBox2.BackColor = System.Drawing.Color.Salmon;
			this.pictureBox2.Location = new System.Drawing.Point(132, 367);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(450, 10);
			this.pictureBox2.TabIndex = 30;
			this.pictureBox2.TabStop = false;
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.Salmon;
			this.pictureBox1.Location = new System.Drawing.Point(134, 141);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(764, 10);
			this.pictureBox1.TabIndex = 29;
			this.pictureBox1.TabStop = false;
			// 
			// pictureBox5
			// 
			this.pictureBox5.BackColor = System.Drawing.Color.MistyRose;
			this.pictureBox5.Location = new System.Drawing.Point(134, 141);
			this.pictureBox5.Name = "pictureBox5";
			this.pictureBox5.Size = new System.Drawing.Size(763, 231);
			this.pictureBox5.TabIndex = 51;
			this.pictureBox5.TabStop = false;
			// 
			// pictureBox9
			// 
			this.pictureBox9.BackColor = System.Drawing.Color.MistyRose;
			this.pictureBox9.Location = new System.Drawing.Point(573, 339);
			this.pictureBox9.Name = "pictureBox9";
			this.pictureBox9.Size = new System.Drawing.Size(325, 109);
			this.pictureBox9.TabIndex = 52;
			this.pictureBox9.TabStop = false;
			// 
			// ZONE
			// 
			this.ZONE.AutoSize = true;
			this.ZONE.BackColor = System.Drawing.Color.MistyRose;
			this.ZONE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
			this.ZONE.ForeColor = System.Drawing.Color.Black;
			this.ZONE.Location = new System.Drawing.Point(158, 205);
			this.ZONE.Name = "ZONE";
			this.ZONE.Size = new System.Drawing.Size(46, 20);
			this.ZONE.TabIndex = 53;
			this.ZONE.Text = "Zone";
			this.ZONE.Paint += new System.Windows.Forms.PaintEventHandler(this.Label6_Paint);
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.BackColor = System.Drawing.Color.MistyRose;
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
			this.label7.ForeColor = System.Drawing.Color.Black;
			this.label7.Location = new System.Drawing.Point(158, 251);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(109, 20);
			this.label7.TabIndex = 54;
			this.label7.Text = "TNI Light stick";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.BackColor = System.Drawing.Color.MistyRose;
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
			this.label8.ForeColor = System.Drawing.Color.Black;
			this.label8.Location = new System.Drawing.Point(158, 302);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(103, 20);
			this.label8.TabIndex = 55;
			this.label8.Text = "Discount   for";
			// 
			// unit_zone
			// 
			this.unit_zone.AutoSize = true;
			this.unit_zone.BackColor = System.Drawing.Color.MistyRose;
			this.unit_zone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
			this.unit_zone.Location = new System.Drawing.Point(676, 205);
			this.unit_zone.Name = "unit_zone";
			this.unit_zone.Size = new System.Drawing.Size(60, 20);
			this.unit_zone.TabIndex = 64;
			this.unit_zone.Text = "label10";
			this.unit_zone.Click += new System.EventHandler(this.Label10_Click_1);
			this.unit_zone.Paint += new System.Windows.Forms.PaintEventHandler(this.Unit_zone_Paint);
			// 
			// price_zone
			// 
			this.price_zone.AutoSize = true;
			this.price_zone.BackColor = System.Drawing.Color.MistyRose;
			this.price_zone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
			this.price_zone.Location = new System.Drawing.Point(792, 204);
			this.price_zone.Name = "price_zone";
			this.price_zone.Size = new System.Drawing.Size(60, 20);
			this.price_zone.TabIndex = 70;
			this.price_zone.Text = "label11";
			this.price_zone.Click += new System.EventHandler(this.Price_zone_Click);
			this.price_zone.Paint += new System.Windows.Forms.PaintEventHandler(this.Price_zone_Paint);
			// 
			// priceTNI
			// 
			this.priceTNI.AutoSize = true;
			this.priceTNI.BackColor = System.Drawing.Color.MistyRose;
			this.priceTNI.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
			this.priceTNI.Location = new System.Drawing.Point(792, 252);
			this.priceTNI.Name = "priceTNI";
			this.priceTNI.Size = new System.Drawing.Size(60, 20);
			this.priceTNI.TabIndex = 72;
			this.priceTNI.Text = "label16";
			this.priceTNI.Paint += new System.Windows.Forms.PaintEventHandler(this.Label16_Paint);
			// 
			// unitTNI
			// 
			this.unitTNI.AutoSize = true;
			this.unitTNI.BackColor = System.Drawing.Color.MistyRose;
			this.unitTNI.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
			this.unitTNI.Location = new System.Drawing.Point(676, 252);
			this.unitTNI.Name = "unitTNI";
			this.unitTNI.Size = new System.Drawing.Size(60, 20);
			this.unitTNI.TabIndex = 71;
			this.unitTNI.Text = "label17";
			this.unitTNI.Click += new System.EventHandler(this.Label17_Click);
			this.unitTNI.Paint += new System.Windows.Forms.PaintEventHandler(this.Label17_Paint);
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.BackColor = System.Drawing.Color.MistyRose;
			this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
			this.label13.Location = new System.Drawing.Point(267, 302);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(60, 20);
			this.label13.TabIndex = 73;
			this.label13.Text = "label13";
			this.label13.Click += new System.EventHandler(this.Label13_Click);
			this.label13.Paint += new System.Windows.Forms.PaintEventHandler(this.Label13_Paint);
			// 
			// T
			// 
			this.T.AutoSize = true;
			this.T.BackColor = System.Drawing.Color.MistyRose;
			this.T.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
			this.T.Location = new System.Drawing.Point(719, 352);
			this.T.Name = "T";
			this.T.Size = new System.Drawing.Size(51, 20);
			this.T.TabIndex = 75;
			this.T.Text = "label6";
			this.T.Click += new System.EventHandler(this.Label6_Click);
			this.T.Paint += new System.Windows.Forms.PaintEventHandler(this.Label6_Paint_1);
			// 
			// Total
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImage = global::TNI_IN_YOUR_ARER.Properties.Resources.Project_BG;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.ClientSize = new System.Drawing.Size(952, 501);
			this.Controls.Add(this.T);
			this.Controls.Add(this.label13);
			this.Controls.Add(this.priceTNI);
			this.Controls.Add(this.unitTNI);
			this.Controls.Add(this.price_zone);
			this.Controls.Add(this.unit_zone);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.ZONE);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.pictureBox8);
			this.Controls.Add(this.pictureBox7);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.pictureBox4);
			this.Controls.Add(this.pictureBox3);
			this.Controls.Add(this.pictureBox2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.pictureBox5);
			this.Controls.Add(this.pictureBox9);
			this.Name = "Total";
			this.Text = "Total";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.PictureBox pictureBox8;
		private System.Windows.Forms.PictureBox pictureBox7;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.PictureBox pictureBox4;
		private System.Windows.Forms.PictureBox pictureBox3;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.PictureBox pictureBox5;
		private System.Windows.Forms.PictureBox pictureBox9;
		private System.Windows.Forms.Label ZONE;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label unit_zone;
		private System.Windows.Forms.Label price_zone;
		private System.Windows.Forms.Label priceTNI;
		private System.Windows.Forms.Label unitTNI;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label T;
	}
}