﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace TNI_IN_YOUR_ARER
{
	public partial class Login : Form
	{
		public Login()
		{
			InitializeComponent();
		}

		private void LinkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			this.Hide();
			Register r1 = new Register();
			r1.Show();

		}

		private void Login_Load(object sender, EventArgs e)
		{

		}

		private void Button1_Click(object sender, EventArgs e)
		{

			if (CheckName(username.Text, password.Text))
			{
				MessageBox.Show("Please enter your Username or Password again.");
			}
			else
			{
				Program.id = username.Text;
				this.Hide();
				Zone z1 = new Zone();
				z1.ShowDialog();
			}
		}

	

		private void Button2_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		private void TextBox1_TextChanged(object sender, EventArgs e)
		{

		}
		static bool CheckName (string id , string pass)
		{
			bool check = true;
			bool TRY = true;
			if (id.Equals("") || pass.Equals(""))
				check = true;
			try
			{
				StreamReader sr = new StreamReader(Program.filename);
				string temp = "";
				while ((temp = sr.ReadLine()) != null)
				{
					string[] data = temp.Split('*');
					if (data[3].Equals(id) && data[4].Equals(pass))
					{
						check = false;
					}
				}
				sr.Close();
			}
			catch
			{
				StreamWriter sw = new StreamWriter(Program.filename);
				sw.Close();
			}
			return check;
		}

		private void Label2_Click(object sender, EventArgs e)
		{

		}
	}
}
