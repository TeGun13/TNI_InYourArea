﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TNI_IN_YOUR_ARER
{
	static class Program
	{
		public static string filename = "D:\\TNI_IN_YOUR_ARER.txt";
		public static string id, password, Email, re_password, fn, sn,Zone;
		public static double price, total,discount,YPRODUCT,WPRODUCT,ALLunitproduct; //total = ราคาโซน discount = ราคาแบบลดแล้ว
		public static int seat,Yproduct,Wproduct,Allproduct; //seat =ที่นั่ง product = จำนวนเเท่งไฟ
		public static string UNIT_ZONE;
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new Form1());
		}
	}
}
