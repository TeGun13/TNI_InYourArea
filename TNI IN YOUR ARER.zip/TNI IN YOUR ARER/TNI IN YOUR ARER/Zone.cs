﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace TNI_IN_YOUR_ARER
{
	public partial class Zone : Form
	{
		public Zone()
		{
			InitializeComponent();
		}

		private void Button2_Click(object sender, EventArgs e)
		{
				try
				{
					string unit = InputSeat.Text;
					int UNIT = int.Parse(unit);
					if (azone.Checked)
					{
						ChoosaZone(azone.Checked, UNIT);
						Program.seat = UNIT;
					this.Hide();
					Product pd = new Product();
					pd.ShowDialog();
				}
					else if (bzone.Checked)
					{
						ChoosbZone(bzone.Checked, UNIT);
						Program.seat = UNIT;
					this.Hide();
					Product pd = new Product();
					pd.ShowDialog();
				}
					else if (czone.Checked)
					{
						ChooscZone(czone.Checked, UNIT);
						Program.seat = UNIT;
					this.Hide();
					Product pd = new Product();
					pd.ShowDialog();
				}
					else if (dzone.Checked)
					{
						ChoosdZone(dzone.Checked, UNIT);
						Program.seat = UNIT;
					this.Hide();
					Product pd = new Product();
					pd.ShowDialog();
				}
				}
				catch
				{
			    	MessageBox.Show("Please choose ZONE or Input your seat");
				}

		}
		static bool ChoosaZone (bool azone,int Seat)
		{
			bool check = true;
			float price, total = 0;
			price = 2000;
			total = price * Seat;
			string user = Program.id;
			try
			{
				StreamReader sr = new StreamReader(Program.filename);
				string temp = "";
				while ((temp = sr.ReadLine()) != null)
				{
					string[] nameInfile = temp.Split('*');
					if (user.Equals(nameInfile[3]))
					{
						user = nameInfile[3];
					}
				}
				sr.Close();
			}
			catch
			{
			}
				StreamWriter sw = new StreamWriter("D:\\AZONE.txt", true);
				sw.WriteLine("A_ZONE*{0}*{1}*{2}*{3}", price,Seat, total,user);
				sw.Close();
			Program.total = total;
			Program.Zone = "Zone \"A\"";
			return check;
		}
		static bool ChoosbZone (bool bzone,int Seat)
		{
			bool check = true;
			float price, total = 0;
			price = 1500;
			total = price * Seat;
			string user = Program.id;

			try
			{
				StreamReader sr = new StreamReader(Program.filename);
				string temp = "";
				while ((temp = sr.ReadLine()) != null)
				{
					string[] nameInfile = temp.Split('*');
					if (user.Equals(nameInfile[3]))
					{
						user = nameInfile[3];
					}
				}
				sr.Close();
			}
			catch
			{
			}
			StreamWriter sw = new StreamWriter("D:\\BZONE.txt", true);
			sw.WriteLine("B_ZONE*{0}*{1}*{2}*{3}", price, Seat, price * Seat, user);
			sw.Close();

			Program.total = price * Seat;
			Program.Zone = "Zone \"B\"";
			return check;
		}
		static bool ChooscZone (bool czone,int Seat)
		{
			bool check = true;
			float price, total = 0;
			price = 1500;
			total = price * Seat;
			string user = Program.id;

			try
			{
				StreamReader sr = new StreamReader(Program.filename);
				string temp = "";
				while ((temp = sr.ReadLine()) != null)
				{
					string[] nameInfile = temp.Split('*');
					if (user.Equals(nameInfile[3]))
					{
						user = nameInfile[3];
					}
				}
				sr.Close();
			}
			catch
			{
			}
			StreamWriter sw = new StreamWriter("D:\\CZONE.txt", true);
			sw.WriteLine("C_ZONE*{0}*{1}*{2}*{3}", price, Seat, price * Seat, user);
			sw.Close();
			Program.total = price * Seat;
			Program.Zone = "Zone \"C\"";
			return check;
		}

		static bool ChoosdZone(bool dzone, int Seat)
		{
			bool check = true;
			float price, total = 0;
			price = 800;
			total = price * Seat;
			string user = Program.id;

			try
			{
				StreamReader sr = new StreamReader(Program.filename);
				string temp = "";
				while ((temp = sr.ReadLine()) != null)
				{
					string[] nameInfile = temp.Split('*');
					if (user.Equals(nameInfile[3]))
					{
						user = nameInfile[3];
					}
				}
				sr.Close();
			}
			catch
			{
			}
			StreamWriter sw = new StreamWriter("D:\\DZONE.txt", true);
			sw.WriteLine("D_ZONE*{0}*{1}*{2}*{3}", price, Seat, price * Seat, user);
			sw.Close();
			Program.total = price * Seat;
			Program.Zone = "Zone \"D\"";
			return check;
		}
		private void CheckBox1_CheckedChanged(object sender, EventArgs e)
		{

		}

		private void CheckBox2_CheckedChanged(object sender, EventArgs e)
		{

		}

		private void CheckBox3_CheckedChanged(object sender, EventArgs e)
		{

		}

		private void CheckBox4_CheckedChanged(object sender, EventArgs e)
		{

		}

		private void TextBox1_TextChanged(object sender, EventArgs e)
		{
			
		}

		private void InputSeat_KeyPress(object sender, KeyPressEventArgs e)
		{
			Char chr = e.KeyChar;
			if (!Char.IsDigit(chr) && chr != 8)
			{
				e.Handled = true;
				MessageBox.Show("Please enter a valid value");
			}
		}

		private void Button1_Click(object sender, EventArgs e)
		{

		}

		private void PictureBox11_Click(object sender, EventArgs e)
		{

		}
	}
}
