﻿namespace TNI_IN_YOUR_ARER
{
	partial class Product
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.ytext = new System.Windows.Forms.TextBox();
			this.wtext = new System.Windows.Forms.TextBox();
			this.button5 = new System.Windows.Forms.Button();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(179, 34);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(637, 65);
			this.label1.TabIndex = 0;
			this.label1.Text = "Do you want TNI Light Stick?";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Font = new System.Drawing.Font("Yu Gothic UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.White;
			this.label2.Location = new System.Drawing.Point(523, 341);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(349, 45);
			this.label2.TabIndex = 2;
			this.label2.Text = "Input Yellow color item";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Font = new System.Drawing.Font("Yu Gothic UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.White;
			this.label3.Location = new System.Drawing.Point(119, 341);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(342, 45);
			this.label3.TabIndex = 3;
			this.label3.Text = "Input White color item";
			// 
			// ytext
			// 
			this.ytext.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
			this.ytext.Location = new System.Drawing.Point(637, 389);
			this.ytext.Name = "ytext";
			this.ytext.Size = new System.Drawing.Size(152, 29);
			this.ytext.TabIndex = 4;
			this.ytext.TextChanged += new System.EventHandler(this.Ytext_TextChanged);
			this.ytext.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Ytext_KeyPress);
			// 
			// wtext
			// 
			this.wtext.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
			this.wtext.Location = new System.Drawing.Point(219, 389);
			this.wtext.Name = "wtext";
			this.wtext.Size = new System.Drawing.Size(152, 29);
			this.wtext.TabIndex = 5;
			this.wtext.TextChanged += new System.EventHandler(this.TextBox2_TextChanged);
			this.wtext.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox2_KeyPress);
			// 
			// button5
			// 
			this.button5.BackColor = System.Drawing.Color.Salmon;
			this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
			this.button5.ForeColor = System.Drawing.Color.White;
			this.button5.Location = new System.Drawing.Point(773, 438);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(127, 38);
			this.button5.TabIndex = 36;
			this.button5.Text = "Confirm";
			this.button5.UseVisualStyleBackColor = false;
			this.button5.Click += new System.EventHandler(this.Button5_Click);
			// 
			// pictureBox2
			// 
			this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox2.BackgroundImage = global::TNI_IN_YOUR_ARER.Properties.Resources.NewCanvas12;
			this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pictureBox2.Location = new System.Drawing.Point(162, 102);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(249, 306);
			this.pictureBox2.TabIndex = 1;
			this.pictureBox2.TabStop = false;
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox1.BackgroundImage = global::TNI_IN_YOUR_ARER.Properties.Resources.NewCanvas123;
			this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pictureBox1.Location = new System.Drawing.Point(579, 102);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(249, 306);
			this.pictureBox1.TabIndex = 1;
			this.pictureBox1.TabStop = false;
			// 
			// Product
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImage = global::TNI_IN_YOUR_ARER.Properties.Resources.Project_BG;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.ClientSize = new System.Drawing.Size(952, 501);
			this.Controls.Add(this.button5);
			this.Controls.Add(this.wtext);
			this.Controls.Add(this.ytext);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.pictureBox2);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.label1);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Product";
			this.Text = "Product";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox ytext;
		private System.Windows.Forms.TextBox wtext;
		private System.Windows.Forms.Button button5;
	}
}