﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace TNI_IN_YOUR_ARER
{
	public partial class Product : Form
	{
		public Product()
		{
			InitializeComponent();
		}

		private void DomainUpDown1_SelectedItemChanged(object sender, EventArgs e)
		{

		}

		private void Button5_Click(object sender, EventArgs e)
		{

			if (Check_y_Unit(ytext.Text))
			{
				int Yunit = int.Parse(ytext.Text);
				Program.Yproduct = Yunit;
			}
			
		    if (Check_w_Unit(wtext.Text))
			{
				int Wunit = int.Parse(wtext.Text);
				Program.Wproduct = Wunit;
			}

			this.Hide();
			Member mb = new Member();
			mb.ShowDialog();
		}
		static bool Check_y_Unit (string y)
		{
			bool check = false;
			try
			{
				int y_unit = int.Parse(y);
				double price = 1800;

				if (y_unit > 0)
				{
					check = true;
					Program.YPRODUCT = price * y_unit;
				}
				else if (y_unit == null)
				{
					check = false;
				}
			}
			catch
			{
				//MessageBox.Show("Yellow item\n"+"Please input your seat or input \"0\"");
			}
			return check;
		}
		static bool Check_w_Unit (string w)
		{
			bool check = false;
			try
			{
				int w_unit = int.Parse(w);
				double price = 1800;

				if (w_unit > 0)
				{
					check = true;
					Program.WPRODUCT = price * w_unit;
				}
				else if (w_unit == null)
				{
					check = false;
				}
			}
			catch
			{
				//MessageBox.Show("White item\n"+"Please input your seat or input \"0\"");
			}
			return check;
		}

		private void TextBox2_TextChanged(object sender, EventArgs e)
		{

		}

		private void Ytext_TextChanged(object sender, EventArgs e)
		{

		}

		private void Ytext_KeyPress(object sender, KeyPressEventArgs e)
		{
			Char chr = e.KeyChar;
			if (!Char.IsDigit(chr) && chr != 8)
			{
				e.Handled = true;
				MessageBox.Show("Please enter a valid value");
			}
		}

		private void TextBox2_KeyPress(object sender, KeyPressEventArgs e)
		{
			Char chr = e.KeyChar;
			if (!Char.IsDigit(chr) && chr != 8)
			{
				e.Handled = true;
				MessageBox.Show("Please enter a valid value");
			}
		}
	}
}
